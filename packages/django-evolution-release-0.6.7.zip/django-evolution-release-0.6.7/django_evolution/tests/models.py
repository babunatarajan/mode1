# This module is used as a placeholder for the registration of test models.
# It is intentionally empty; individual tests create and register models
# that will appear to Django as if they are in this module.
